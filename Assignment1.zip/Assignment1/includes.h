#pragma once

#define ARR_SIZE 49
#define WIDTH 7

#include <iostream>
#include <thread>
#include <vector>
#include <stack>
#include <unordered_map>
#include <string>
#include <queue>